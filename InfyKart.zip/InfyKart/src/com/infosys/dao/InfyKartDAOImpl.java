package com.infosys.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.infosys.entity.Gadget;

public class InfyKartDAOImpl implements InfyKartDAO {
	private static Map<Integer, Gadget> gadgetRepository = new LinkedHashMap<>();

	static {
		gadgetRepository.put(101, new Gadget(101, "Laptop", "HP", 90000, 50));
		gadgetRepository.put(102, new Gadget(102, "Mobile", "Redmi", 8000, 10));
		gadgetRepository.put(103, new Gadget(103, "Smart Watch", "Samsung", 25000, 2));
	}

	@Override
	public boolean addGadget(Gadget gadget) {
		if (!gadgetRepository.containsKey(gadget.getId())) {
			gadgetRepository.put(gadget.getId(), gadget);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Gadget getGadget(int gadgetId) {
		if (gadgetRepository.containsKey(gadgetId)) {
			return gadgetRepository.get(gadgetId);
		} else {
			return null;
		}
	}

	@Override
	public float updateGadgetPrice(int gadgetId, float newPrice) {
		if (gadgetRepository.containsKey(gadgetId)) {
			Gadget gadget = gadgetRepository.get(gadgetId);
			gadget.setPrice(gadget.getPrice() + newPrice);
			return gadget.getPrice();
		} else {
			return 0;
		}
	}

	@Override
	public int updateGadgetQuantity(int gadgetId, int newQuantity) {
		if (gadgetRepository.containsKey(gadgetId)) {
			Gadget gadget = gadgetRepository.get(gadgetId);
			gadget.setQuantity(gadget.getQuantity() + newQuantity);
			return gadget.getQuantity();
		} else {
			return 0;
		}
	}

	@Override
	public boolean removeGadget(int gadgetId) {
		if (gadgetRepository.containsKey(gadgetId)) {
			gadgetRepository.remove(gadgetId);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<Gadget> viewAllGadgets() {
		Set<Integer> keySet = gadgetRepository.keySet();
		List<Gadget> gadgetList = new ArrayList<>();
		for (Integer key : keySet) {
			gadgetList.add(gadgetRepository.get(key));
		}
		return gadgetList;
	}
}
