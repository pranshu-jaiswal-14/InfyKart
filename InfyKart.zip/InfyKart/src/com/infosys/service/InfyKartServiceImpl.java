package com.infosys.service;

import java.util.List;

import com.infosys.dao.InfyKartDAO;
import com.infosys.dao.InfyKartDAOImpl;
import com.infosys.entity.Gadget;
import com.infosys.exception.InfyKartException;

public class InfyKartServiceImpl implements InfyKartService {
	private InfyKartDAO infyKartDAO = new InfyKartDAOImpl();

	@Override
	public String addGadget(Gadget gadget) throws InfyKartException {
		if (infyKartDAO.addGadget(gadget)) {
			return "New Gadget added successfully.";
		} else {
			throw new InfyKartException("Gadget already available.");
		}
	}

	@Override
	public Gadget getGadget(int gadgetId) {
		return infyKartDAO.getGadget(gadgetId);
	}

	@Override
	public float updateGadgetPrice(int gadgetId, float newPrice) throws InfyKartException {
		float i = infyKartDAO.updateGadgetPrice(gadgetId, newPrice);
		if (i < 0) {
			throw new InfyKartException("Gadget price cannot be negative");
		} else if (i == 0) {
			throw new InfyKartException("Gadget not available.");
		} else {
			return i;
		}
	}

	@Override
	public int updateGadgetQuantity(int gadgetId, int newQuantity) {
		int i = infyKartDAO.updateGadgetQuantity(gadgetId, newQuantity);
		if (i < 0) {
			return -1;
		} else if (i == 0) {
			return 0;
		} else {
			return i;
		}
	}

	@Override
	public boolean removeGadget(int gadgetId) {
		return infyKartDAO.removeGadget(gadgetId);
	}

	@Override
	public List<Gadget> viewAllGadgets() {
		return infyKartDAO.viewAllGadgets();
	}

}
