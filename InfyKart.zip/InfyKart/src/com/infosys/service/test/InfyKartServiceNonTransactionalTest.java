package com.infosys.service.test;

class InfyKartServiceNonTransactionalTest {

}
