package com.infosys.exception;

public class InfyKartException extends Exception {
	private static final long serialVersionUID = 1L;

	public InfyKartException(String message) {
		super(message);
	}
}
