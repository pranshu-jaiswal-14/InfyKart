package com.infosys.entity;

public class Gadget {
	private int id;
	private String name;
	private String manufacturedBy;
	private float price;
	private int quantity;

	public Gadget() {
		super();
	}

	public Gadget(int id, String name, String manufacturedBy, float price, int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.manufacturedBy = manufacturedBy;
		this.price = price;
		this.quantity = quantity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getManufacturedBy() {
		return manufacturedBy;
	}

	public void setManufacturedBy(String manufacturedBy) {
		this.manufacturedBy = manufacturedBy;
	}

	@Override
	public int hashCode() {
		return 1;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else {
			if (this.getClass() != obj.getClass()) {
				return false;
			} else {
				Gadget gadget = (Gadget) obj;
				return this.id == gadget.id && this.name.equals(gadget.name);
			}
		}
	}

	@Override
	public String toString() {
		return "Gadget [Id=" + id + ", Name=" + name + ", Quantity=" + quantity + ", Price=" + price
				+ ", Manufactured By=" + manufacturedBy + "]";
	}
}
